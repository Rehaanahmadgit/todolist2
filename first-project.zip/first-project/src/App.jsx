import { useEffect, useState, useRef } from 'react'
import Header from './component/header'
import Footer from './component/footer'
import Card from './component/card'

function App() {
  const [count, setCount] = useState(0)
const [first, setfirst] = useState(0)
  
// useEffect(() => {

// alert("haii wellcome to my page")
//   },
//  [])

// useEffect(() => {
//   alert(" count change")
  
// }, [count])


const a = useRef(0);

  useEffect(() => {
    a.current = a.current + 1;
    console.log(`I am number change ${a.current}`);
  }, []); 





  return (
  <div className='App'>
    <Header textlogo="rehaan logo"/>
<div className='cards'>
 <Card title="carde 1" description="description 1"/>
 <Card title="carde 2" description="description 2"/>
 <Card title="carde 3" description="description 3"/>

</div>
   
    <div className="value">{count}</div>
    <button onClick={()=>{setCount(count+1)}}>click</button>
   
   <Footer/>
   </div>
    
  );
}

export default App
