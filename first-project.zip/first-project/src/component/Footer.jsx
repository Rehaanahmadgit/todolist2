import React from 'react'
import "./footer.css"
function footer() {
  
  
  return (
	<div className='footer1'>footer</div>
  )
}

export default footer
