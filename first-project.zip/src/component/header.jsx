import React from 'react'
import Footer from './footer';
import "./header.css"
const Header =(props)=> {
	console.log("huuu",props.textlogo)
  return (
	<div >
	<nav>
	<ul>
		<li >home </li>
		<li >contract </li>
		<li > about </li>
	</ul>
	</nav>
	</div>
  );
}

export default Header